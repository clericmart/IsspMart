package ua.web.martynenko.film;

import java.util.Map;

public interface Action {
	String run(Map<String, String[]> m);
}
